import hashlib
import datetime
from django.contrib.auth.models import AbstractUser
from django.utils.translation import gettext_lazy as _
from django.db import models

from users.managers import CustomUserManager


class ActivationToken(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    email = models.EmailField()
    valid_through = models.DateTimeField(null=True)
    token = models.CharField(max_length=255, null=True)
    email_verified = models.BooleanField(default=False)

    def save(self, *args, **kwargs):
        if not self.token:
            data = f"{self.email}-{self.timestamp}"
            token = hashlib.sha256(data.encode('utf-8')).hexdigest()
            self.token = token
            self.valid_through = self.timestamp + datetime.timedelta(days=1)
        super(ActivationToken, self).save(*args, **kwargs)

    def __str__(self):
        return self.token


class User(AbstractUser):
    username = None
    email = models.EmailField(
        max_length=100,
        unique=True,
        verbose_name=_("Email address")
    )
    avatar = models.FileField(
        upload_to='avatar',
        blank=True, null=True,
        verbose_name=_('Avatar'),
    )
    first_name = models.CharField(
        max_length=255,
        blank=True, null=True,
        verbose_name=_("First name")
    )
    last_name = models.CharField(
        max_length=255,
        blank=True, null=True,
        verbose_name=_("Last name")
    )
    birth_date = models.DateField(
        blank=True, null=True,
        verbose_name=_('Birth date'),
    )
    phone_number = models.CharField(
        max_length=20,
        blank=True, null=True,
        verbose_name=_('Phone number')
    )
    instagram = models.CharField(
        max_length=255,
        blank=True, null=True,
        verbose_name='Instagram'
    )
    linkedin = models.CharField(
        max_length=255,
        blank=True, null=True,
        verbose_name='LinkedIn'
    )
    facebook = models.CharField(
        max_length=255,
        blank=True, null=True,
        verbose_name='Facebook'
    )
    vk = models.CharField(
        max_length=255,
        blank=True, null=True,
        verbose_name='VK'
    )
    is_active = models.BooleanField(default=False)
    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = []

    objects = CustomUserManager()

    class Meta:
        verbose_name = _("User")
        verbose_name_plural = _("Users")
        ordering = ("-id",)

    def __str__(self):
        return self.email
