from django.conf import settings


def change_path(path: str) -> str:
    relative_path_start = path.find('/media')
    relative_path = path[relative_path_start:]
    return f'{settings.DOMAIN}{relative_path}'
