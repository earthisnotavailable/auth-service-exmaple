import datetime
from django.contrib.auth import get_user_model

from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework import viewsets, mixins, status

from . import serializers, models


User = get_user_model()


class UserViewSet(mixins.RetrieveModelMixin,
                  mixins.UpdateModelMixin,
                  mixins.CreateModelMixin,
                  viewsets.GenericViewSet):
    serializer_class = serializers.UserSerializer

    def get_queryset(self):
        return User.objects.filter(pk=self.request.user.pk)

    def get_serializer_class(self):
        if self.action in ['create']:
            return serializers.UserCreateSerializer
        return self.serializer_class

    def get_object(self):
        return self.request.user

    def get_permissions(self):
        if self.action in ['retrieve', 'update']:
            return [IsAuthenticated()]
        return [AllowAny()]
    
    @action(detail=False, permission_classes=[AllowAny], methods=['get'])
    def activate(self, request, pk=None):
        email = request.query_params.get('user_email', '')
        confirmation_token = request.query_params.get('confirmation_token', '')
        try:
            token = models.ActivationToken.objects.get(email=email, token=confirmation_token)
        except(TypeError, ValueError, OverflowError, models.ActivationToken.DoesNotExist):
            token = None
        if token is None:
            return Response({'detail': 'Token is not valid'}, status=status.HTTP_400_BAD_REQUEST)
        if datetime.datetime.now() > token.valid_through:
            return Response(
                'Token is expired. Please request another confirmation email by signing in.', 
                status=status.HTTP_400_BAD_REQUEST
            )
        token.email_verified = True
        token.save()
        return Response({'detail': 'Email successfully confirmed'}, status=status.HTTP_200_OK)

    @action(detail=True, permission_classes=[IsAuthenticated], methods=['post'])
    def change_password(self, request, pk=None):
        user = self.get_object()
        serializer = serializers.ChangePasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        old_password = serializer.data.get('old_password')
        new_password = serializer.data.get('new_password')
        if not user.check_password(old_password):
            return Response(
                {"old_password": ["Wrong password."]}, 
                status=status.HTTP_400_BAD_REQUEST
            )
        user.set_password(new_password)
        user.save()
        return Response(
            {"detail": 'Password updated successfully'}, 
            status=status.HTTP_200_OK
        )


class TokenActivationViewSet(mixins.CreateModelMixin, viewsets.GenericViewSet):
    queryset = models.ActivationToken.objects.all()
    serializer_class = serializers.ActivationTokenSerializer
