from django.contrib.auth import get_user_model, password_validation
from rest_framework import serializers

from .utils import change_path
from .tasks import send_account_confirmation_link
from .models import ActivationToken

User = get_user_model()


class UserCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = (
            'id', 'email', 'avatar', 'first_name', 
            'last_name', 'birth_date', 'phone_number',
            'instagram', 'linkedin', 'facebook', 'vk',
            'password',
        )
    
    def validate_password(self, value):
        password_validation.validate_password(value)

    def validate_email(self, value):
        try:
            ActivationToken.objects.get(email=value, email_verified=True)
        except ActivationToken.DoesNotExist as e:
            raise serializers.ValidationError({'error': 'Email is not verified'}) from e
        
    def create(self, validated_data):
        password = validated_data.pop('password')
        user = super().create(validated_data)
        user.set_password(password)
        user.save()


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = (
            'id', 'email', 'avatar', 'first_name', 
            'last_name', 'birth_date', 'phone_number',
            'instagram', 'linkedin', 'facebook', 'vk',
        )
        read_only_fields = ('id', 'email')

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        path = representation['avatar']
        if path:
            path = change_path(path)
        representation['avatar'] = path
        return representation


class ChangePasswordSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)



class ActivationTokenSerializer(serializers.ModelSerializer):
    class Meta:
        model = ActivationToken
        fields = ('email', 'is_active', 'valid_through', 'timestamp')
        read_only_fields = ('valid_through', 'timestamp', 'token')

    def create(self, validated_data):
        token_obj = ActivationToken.objects.create(**validated_data)
        send_account_confirmation_link.delay(token_obj.email, token_obj.token)
        return token_obj
