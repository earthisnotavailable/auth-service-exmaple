from django.conf import settings
from django.core.mail import send_mail
from accounts_service.celery import app


@app.task
def send_account_confirmation_link(email, token):
    link = f'{settings.ACTIVATION_LINK_DOMAIN}/users/activate?user_email={email}&confirmation_token={token}'
    subject = 'Подтверждение почты для startup.jva.vc'
    content = f'Подтвердите почту перейдя по ссылке {link}'
    send_mail(
        subject=subject, 
        message=content,
        recipient_list=[email],
        from_email=settings.EMAIL_HOST_USER, 
        fail_silently=True,
    )
